export enum UserType {
  ADMIN = 'admin',
  SUB = 'sub',
  DIRECTORATE = 'directorate',
  ADMINISTRATION = 'administration',
  COORDINATOR = 'coordinator',
  MEMORIZER = 'memorizer',
}

export enum AdministrationType {
  DIRECTOR_DEPARTMENT = 'director_department',
  ADMINISTRATIVE_QURAN = 'administrative_quran',
  SCIENTIFIC_QURAN = 'scientific_quran',
  ADMINISTRATIVE_ISLAMIC_AND_ARABIC_SCIENCES = 'administrative_islamic_and_arabic_sciences',
  SCIENTIFIC_ISLAMIC_AND_ARABIC_SCIENCES = 'scientific_islamic_and_arabic_sciences',
  SCIENTIFIC_READINGS = 'scientific_readings',
  TECHNICAL = 'technical',
}

export enum Specialization {
  ADMINISTRATIVE = 'administrative',
  SCIENTIFIC = 'scientific',
}

export enum UserCondition {
  RESIDENCE = 'residence',
  WAITING = 'waiting',
  EXCLUDED = 'excluded',
  APOLOGY = 'apology',
  MANAGEMENT_MEMBER = 'management_member',
  DIED = 'died',
  SUSPENDED = 'suspended',
  LEAVE = 'leave',
  OTHER = 'other',
}
