export enum MemorizationLevel {
  NONE = 'none',
  SELECT = 'select',
  ALL = 'all',
}
