export enum StudentType {
  MEN = 'men',
  WOMEN = 'women',
  CHILDREN = 'children',
}

export enum MemorizerType {
  BASIC = 'basic',
  SECONDED = 'seconded',
}
