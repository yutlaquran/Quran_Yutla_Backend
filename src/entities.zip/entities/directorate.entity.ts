import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Area } from './area.entity';
import { Branch } from './branch.entity';
import { Room } from './room.entity';
import { Student } from './student.entity';
import { User } from './user.entity';
import { Watchtower } from './watchtower.entity';

@Entity('directorates')
export class Directorate {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  name: string;

  @Column({ name: 'admin_id' })
  adminId: number;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  // Relationships
  @ManyToOne(() => User, (user) => user.directorates, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'admin_id' })
  admin: User;

  @OneToMany(() => Area, (area) => area.directorate)
  areas: Area[];

  @OneToMany(() => Branch, (branch) => branch.directorate)
  branches: Branch[];

  @OneToMany(() => User, (user) => user.directorate)
  users: User[];

  @OneToMany(() => Student, (student) => student.directorate)
  students: Student[];

  @OneToMany(() => Room, (room) => room.directorate)
  rooms: Room[];

  @OneToMany(() => Watchtower, (watchtower) => watchtower.directorate)
  watchtowers: Watchtower[];
}
