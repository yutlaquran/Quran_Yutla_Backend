import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Branch } from './branch.entity';
import { Directorate } from './directorate.entity';
import { Room } from './room.entity';
import { Student } from './student.entity';
import { User } from './user.entity';
import { Watchtower } from './watchtower.entity';

@Entity('areas')
export class Area {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ name: 'directorate_id' })
  directorateId: number;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  // Relationships
  @ManyToOne(() => Directorate, (directorate) => directorate.areas, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'directorate_id' })
  directorate: Directorate;

  @OneToMany(() => Branch, (branch) => branch.area)
  branches: Branch[];

  @OneToMany(() => User, (user) => user.area)
  users: User[];

  @OneToMany(() => Student, (student) => student.area)
  students: Student[];

  @OneToMany(() => Room, (room) => room.area)
  rooms: Room[];

  @OneToMany(() => Watchtower, (watchtower) => watchtower.area)
  watchtowers: Watchtower[];
}
