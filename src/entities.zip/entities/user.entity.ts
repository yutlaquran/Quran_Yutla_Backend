import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import {
  AdministrationType,
  Specialization,
  UserCondition,
  UserType,
} from '../enums/user.enum';
import { Area } from './area.entity';
import { Branch } from './branch.entity';
import { Corridor } from './corridor.entity';
import { Directorate } from './directorate.entity';
import { Room } from './room.entity';

export {
  AdministrationType,
  Specialization,
  UserCondition,
  UserType,
} from '../enums/user.enum';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ select: false })
  password!: string;

  @Column({ unique: true, nullable: true })
  email: string;

  @Column({ unique: true, nullable: true })
  phoneNumber: string;

  @Column({
    type: 'enum',
    enum: UserType,
  })
  type: UserType;

  @Column({
    type: 'enum',
    enum: AdministrationType,
    nullable: true,
    name: 'administration_type',
  })
  administrationType: AdministrationType;

  @Column()
  name: string;

  @Column({ default: true })
  status: boolean;

  @Column({ nullable: true, name: 'record_no' })
  recordNumber: string;

  @Column({ nullable: true, name: 'national_id' })
  nationalId: string;

  @Column({ nullable: true })
  job: string;

  @Column({ nullable: true })
  employer: string;

  @Column({
    type: 'enum',
    enum: Specialization,
    nullable: true,
  })
  specialization: Specialization;

  @Column({ nullable: true })
  degree: string;

  @Column({ nullable: true })
  qualification: string;

  @Column({ nullable: true, name: 'resolution_number' })
  resolutionNumber: string;

  @Column({ nullable: true, name: 'contest_date' })
  contestDate: string;

  @Column({
    type: 'enum',
    enum: UserCondition,
    nullable: true,
  })
  condition: UserCondition;

  @Column({ nullable: true })
  address: string;

  @Column({ nullable: true })
  phone: string;

  @Column({ nullable: true, name: 'directorate_id' })
  directorateId: number;

  @Column({ nullable: true, name: 'area_id' })
  areaId: number;

  @Column({ nullable: true, name: 'branch_id' })
  branchId: number;

  @Column({ nullable: true, name: 'corridor_id' })
  corridorId: number;

  @Column({ nullable: true, name: 'email_verified_at' })
  emailVerifiedAt: Date;

  @ManyToOne(() => Directorate, (directorate) => directorate.users)
  @JoinColumn({ name: 'directorate_id' })
  directorate: Directorate;

  @OneToMany(() => Directorate, (directorate) => directorate.admin)
  directorates: Directorate[];

  @ManyToOne(() => Area, (area) => area.users)
  @JoinColumn({ name: 'area_id' })
  area: Area;

  @ManyToOne(() => Branch, (branch) => branch.users)
  @JoinColumn({ name: 'branch_id' })
  branch: Branch;

  @ManyToOne(() => Corridor, (corridor) => corridor.users)
  @JoinColumn({ name: 'corridor_id' })
  corridor: Corridor;

  @OneToMany(() => Room, (room) => room.memorizer)
  rooms: Room[];
}
