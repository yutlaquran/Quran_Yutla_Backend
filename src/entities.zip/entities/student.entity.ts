import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Gender } from '../enums/student.enum';
import { Area } from './area.entity';
import { AttendanceWithStudent } from './attendance-with-student.entity';
import { Branch } from './branch.entity';
import { Directorate } from './directorate.entity';
import { Room } from './room.entity';

@Entity('students')
export class Student {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ nullable: true, name: 'national_id' })
  nationalID: string;

  @Column({
    type: 'enum',
    enum: Gender,
  })
  gender: Gender;

  @Column({ nullable: true })
  birthdate: string;

  @Column({ nullable: true })
  phone: string;

  @Column({ nullable: true })
  address: string;

  @Column({ nullable: true })
  qualification: string;

  @Column({ nullable: true })
  job: string;

  @Column({ default: false, name: 'is_approved' })
  isApproved: boolean;

  @Column({ name: 'directorate_id' })
  directorateId: number;

  @Column({ name: 'area_id' })
  areaId: number;

  @Column({ name: 'branch_id' })
  branchId: number;

  @Column({ name: 'room_id' })
  roomId: number;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  // Relationships
  @ManyToOne(() => Directorate, (directorate) => directorate.students, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'directorate_id' })
  directorate: Directorate;

  @ManyToOne(() => Area, (area) => area.students)
  @JoinColumn({ name: 'area_id' })
  area: Area;

  @ManyToOne(() => Branch, (branch) => branch.students, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'branch_id' })
  branch: Branch;

  @ManyToOne(() => Room, (room) => room.students, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'room_id' })
  room: Room;

  @OneToMany(() => AttendanceWithStudent, (aws) => aws.student)
  attendanceWithStudents: AttendanceWithStudent[];
}
