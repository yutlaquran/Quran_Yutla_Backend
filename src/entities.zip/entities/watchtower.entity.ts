import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Area } from './area.entity';
import { Branch } from './branch.entity';
import { Directorate } from './directorate.entity';

@Entity('watchtowers')
export class Watchtower {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  model: string;

  @Column()
  action: string;

  @Column()
  intended: string;

  @Column({ name: 'user_name' })
  userName: string;

  @Column({ name: 'user_id' })
  userId: number;

  @Column({ nullable: true, name: 'directorate_id' })
  directorateId: number;

  @Column({ nullable: true, name: 'area_id' })
  areaId: number;

  @Column({ nullable: true, name: 'branch_id' })
  branchId: number;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  // Relationships
  @ManyToOne(() => Directorate, (directorate) => directorate.watchtowers)
  @JoinColumn({ name: 'directorate_id' })
  directorate: Directorate;

  @ManyToOne(() => Area, (area) => area.watchtowers)
  @JoinColumn({ name: 'area_id' })
  area: Area;

  @ManyToOne(() => Branch, (branch) => branch.watchtowers)
  @JoinColumn({ name: 'branch_id' })
  branch: Branch;
}
