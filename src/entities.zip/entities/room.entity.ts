import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { MemorizerType, StudentType } from '../enums/room.enum';
import { Area } from './area.entity';
import { AttendanceWithStudent } from './attendance-with-student.entity';
import { Attendance } from './attendance.entity';
import { Branch } from './branch.entity';
import { CorridorLevel } from './corridor-level.entity';
import { Corridor } from './corridor.entity';
import { Directorate } from './directorate.entity';
import { Student } from './student.entity';
import { User } from './user.entity';

@Entity('rooms')
export class Room {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ name: 'room_id' })
  roomID: string;

  @Column({
    type: 'enum',
    enum: StudentType,
    name: 'student_type',
  })
  studentType: StudentType;

  @Column({
    type: 'enum',
    enum: MemorizerType,
    name: 'memorizer_type',
    default: MemorizerType.BASIC,
  })
  memorizerType: MemorizerType;

  @Column({ nullable: true })
  workdays: string;

  @Column({ type: 'time', nullable: true, name: 'time_of' })
  timeOf: string;

  @Column({ type: 'time', nullable: true, name: 'time_to' })
  timeTo: string;

  @Column({ name: 'directorate_id' })
  directorateId: number;

  @Column({ name: 'area_id' })
  areaId: number;

  @Column({ name: 'branch_id' })
  branchId: number;

  @Column({ name: 'corridor_id' })
  corridorId: number;

  @Column({ name: 'level_id' })
  levelId: number;

  @Column({ name: 'memorizer_id' })
  memorizerId: number;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  // Relationships
  @ManyToOne(() => Directorate, (directorate) => directorate.rooms, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'directorate_id' })
  directorate: Directorate;

  @ManyToOne(() => Area, (area) => area.rooms)
  @JoinColumn({ name: 'area_id' })
  area: Area;

  @ManyToOne(() => Branch, (branch) => branch.rooms, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'branch_id' })
  branch: Branch;

  @ManyToOne(() => Corridor, (corridor) => corridor.rooms)
  @JoinColumn({ name: 'corridor_id' })
  corridor: Corridor;

  @ManyToOne(() => CorridorLevel, (level) => level.rooms)
  @JoinColumn({ name: 'level_id' })
  level: CorridorLevel;

  @ManyToOne(() => User, (user) => user.rooms)
  @JoinColumn({ name: 'memorizer_id' })
  memorizer: User;

  @OneToMany(() => Student, (student) => student.room)
  students: Student[];

  @OneToMany(() => Attendance, (attendance) => attendance.room)
  attendances: Attendance[];

  @OneToMany(() => AttendanceWithStudent, (aws) => aws.room)
  attendanceWithStudents: AttendanceWithStudent[];
}
