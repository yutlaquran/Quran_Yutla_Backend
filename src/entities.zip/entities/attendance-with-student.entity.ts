import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Attendance } from './attendance.entity';
import { Room } from './room.entity';
import { Student } from './student.entity';

@Entity('attendance_with_students')
export class AttendanceWithStudent {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  status: boolean;

  @Column({ name: 'student_id' })
  studentId: number;

  @Column({ name: 'attendance_id' })
  attendanceId: number;

  @Column({ name: 'room_id' })
  roomId: number;

  // Relationships
  @ManyToOne(() => Student, (student) => student.attendanceWithStudents, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'student_id' })
  student: Student;

  @ManyToOne(
    () => Attendance,
    (attendance) => attendance.attendanceWithStudents,
    {
      onDelete: 'CASCADE',
    },
  )
  @JoinColumn({ name: 'attendance_id' })
  attendance: Attendance;

  @ManyToOne(() => Room, (room) => room.attendanceWithStudents, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'room_id' })
  room: Room;
}
