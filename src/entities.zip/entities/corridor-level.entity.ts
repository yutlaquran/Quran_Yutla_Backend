import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { Corridor } from './corridor.entity';
import { Room } from './room.entity';

@Entity('corridor_levels')
@Unique(['name', 'corridorId'])
export class CorridorLevel {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ name: 'corridor_id' })
  corridorId: number;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  // Relationships
  @ManyToOne(() => Corridor, (corridor) => corridor.levels, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'corridor_id' })
  corridor: Corridor;

  @OneToMany(() => Room, (room) => room.level)
  rooms: Room[];
}
