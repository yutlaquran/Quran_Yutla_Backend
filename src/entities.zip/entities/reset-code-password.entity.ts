import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity('reset_codes_passwords')
export class ResetCodePassword {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  email: string;

  @Column()
  code: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  // Method to check if code is expired
  isExpired(): boolean {
    const expireTime = new Date(this.createdAt.getTime() + 60 * 60 * 1000); // 1 hour
    return new Date() > expireTime;
  }
}
