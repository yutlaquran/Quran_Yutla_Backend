import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Area } from './area.entity';
import { Corridor } from './corridor.entity';
import { Directorate } from './directorate.entity';
import { Room } from './room.entity';
import { Student } from './student.entity';
import { User } from './user.entity';
import { Watchtower } from './watchtower.entity';

@Entity('branches')
export class Branch {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  name: string;

  @Column({ nullable: true })
  address: string;

  @Column({ nullable: true })
  phone: string;

  @Column({ nullable: true, name: 'resolution_number' })
  resolutionNumber: string;

  @Column({ nullable: true })
  workdays: string;

  @Column({ type: 'time', nullable: true, name: 'time_of' })
  timeOf: string;

  @Column({ type: 'time', nullable: true, name: 'time_to' })
  timeTo: string;

  @Column({ name: 'directorate_id' })
  directorateId: number;

  @Column({ name: 'area_id' })
  areaId: number;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  // Relationships
  @ManyToOne(() => Directorate, (directorate) => directorate.branches, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'directorate_id' })
  directorate: Directorate;

  @ManyToOne(() => Area, (area) => area.branches)
  @JoinColumn({ name: 'area_id' })
  area: Area;

  @OneToMany(() => User, (user) => user.branch)
  users: User[];

  @OneToMany(() => Student, (student) => student.branch)
  students: Student[];

  @OneToMany(() => Room, (room) => room.branch)
  rooms: Room[];

  @ManyToMany(() => Corridor, (corridor) => corridor.branches)
  @JoinTable({
    name: 'branch_with_corridors',
    joinColumn: { name: 'branch_id', referencedColumnName: 'id' },
    inverseJoinColumn: { name: 'corridor_id', referencedColumnName: 'id' },
  })
  corridors: Corridor[];

  @OneToMany(() => Watchtower, (watchtower) => watchtower.branch)
  watchtowers: Watchtower[];

  // Computed properties for specific user types
  get coordinators(): User[] {
    return this.users?.filter((user) => user.type === 'coordinator') || [];
  }

  get memorizers(): User[] {
    return this.users?.filter((user) => user.type === 'memorizer') || [];
  }
}
