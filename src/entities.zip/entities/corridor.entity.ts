import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToMany,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { MemorizationLevel } from '../enums/corridor.enum';
import { Branch } from './branch.entity';
import { CorridorLevel } from './corridor-level.entity';
import { Room } from './room.entity';
import { User } from './user.entity';

@Entity('corridors')
export class Corridor {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  name: string;

  @Column({
    type: 'enum',
    enum: MemorizationLevel,
    name: 'memorization_level',
  })
  memorizationLevel: MemorizationLevel;

  @Column({
    type: 'decimal',
    precision: 5,
    scale: 2,
    nullable: true,
    name: 'min_age',
  })
  minAge: number;

  @Column({
    type: 'decimal',
    precision: 5,
    scale: 2,
    nullable: true,
    name: 'max_age',
  })
  maxAge: number;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  // Relationships
  @OneToMany(() => CorridorLevel, (level) => level.corridor)
  levels: CorridorLevel[];

  @ManyToMany(() => Branch, (branch) => branch.corridors)
  branches: Branch[];

  @OneToMany(() => User, (user) => user.corridor)
  users: User[];

  @OneToMany(() => Room, (room) => room.corridor)
  rooms: Room[];
}
