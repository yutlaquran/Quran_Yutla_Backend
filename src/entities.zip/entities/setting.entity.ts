import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity('settings')
export class Setting {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ nullable: true, name: 'site_name' })
  siteName: string;

  @Column({ nullable: true, name: 'site_title' })
  siteTitle: string;

  @Column({ nullable: true, name: 'site_screen' })
  siteScreen: string;

  @Column({ nullable: true, name: 'site_short_description' })
  siteShortDescription: string;

  @Column({ nullable: true, name: 'site_footer_description' })
  siteFooterDescription: string;

  @Column({ nullable: true, name: 'site_keyworks' })
  siteKeyworks: string;

  @Column({ nullable: true, name: 'site_description' })
  siteDescription: string;

  @Column({ nullable: true, name: 'site_logo_light' })
  siteLogoLight: string;

  @Column({ nullable: true, name: 'site_logo_dark' })
  siteLogoDark: string;

  @Column({ nullable: true, name: 'site_copyright' })
  siteCopyright: string;

  @Column({ nullable: true, name: 'link_twitter' })
  linkTwitter: string;

  @Column({ nullable: true, name: 'link_youtube' })
  linkYoutube: string;

  @Column({ nullable: true, name: 'link_facebook' })
  linkFacebook: string;

  @Column({ nullable: true, name: 'link_instagram' })
  linkInstagram: string;

  @Column({ nullable: true, name: 'contact_email_sales' })
  contactEmailSales: string;

  @Column({ nullable: true, name: 'contact_email_support' })
  contactEmailSupport: string;

  @Column({ nullable: true, name: 'contact_email_administration' })
  contactEmailAdministration: string;

  @Column({ nullable: true, name: 'contact_mobile_sales' })
  contactMobileSales: string;

  @Column({ nullable: true, name: 'contact_mobile_sales2' })
  contactMobileSales2: string;

  @Column({ nullable: true, name: 'contact_mobile_support' })
  contactMobileSupport: string;

  @Column({ nullable: true, name: 'contact_mobile_administration' })
  contactMobileAdministration: string;

  @Column({ nullable: true, name: 'contact_phone_sales' })
  contactPhoneSales: string;

  @Column({ nullable: true, name: 'contact_phone_support' })
  contactPhoneSupport: string;

  @Column({ nullable: true, name: 'contact_phone_administration' })
  contactPhoneAdministration: string;

  @Column({ nullable: true, name: 'contact_title' })
  contactTitle: string;

  @Column({ nullable: true, name: 'contact_description' })
  contactDescription: string;

  @Column({ nullable: true })
  header: string;

  @Column({ nullable: true, name: 'status_front_applicant_add' })
  statusFrontApplicantAdd: boolean;

  @Column({ nullable: true, name: 'status_front_student_edit' })
  statusFrontStudentEdit: boolean;

  @Column({ nullable: true, name: 'student_status_add' })
  studentStatusAdd: boolean;

  @Column({ nullable: true, name: 'student_status_edit' })
  studentStatusEdit: boolean;

  @Column({ nullable: true, name: 'student_status_delete' })
  studentStatusDelete: boolean;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}
